#!/usr/bin/env bash
set -euo pipefail

# يفك أرشيف المشروع الداخلي ويستبدل الملفات القديمة بنفس الأسماء.
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

if ! command -v unzip >/dev/null 2>&1; then
  echo "unzip غير مثبت. ثبّته أولاً: apt-get update && apt-get install -y unzip"
  exit 1
fi

if [ ! -f "Cloud-main.zip" ]; then
  echo "لم أجد Cloud-main.zip بجانب هذا الملف."
  exit 1
fi

echo "جاري فك ملفات المشروع..."
unzip -o "Cloud-main.zip" -d "$HERE"

echo "تم فك الملفات واستبدال الملفات الموجودة."
echo "مجلد المشروع: $HERE/Cloud-main"
echo "لعرض الملفات نفّذ: ls -la Cloud-main"
