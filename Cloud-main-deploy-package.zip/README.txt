حزمة نشر Cloud-main

1) ارفع هذا الملف ZIP إلى GitHub.
2) في بيئة Linux/Terminal نزّل الملف ثم فك الحزمة الخارجية:
   unzip -o Cloud-main-deploy-package.zip -d deploy-package
3) ادخل للمجلد:
   cd deploy-package
4) شغّل سكربت التفكيك:
   bash extract.sh
5) ستجد ملفات المشروع داخل Cloud-main/، وسيتم استبدال الملفات الموجودة بنفس الأسماء.

ملاحظة: السكربت لا يعمل تلقائياً بمجرد رفع ZIP إلى GitHub أو Railway؛ يجب تشغيله بأمر bash.
لا ترفع BOT_TOKEN أو ملف .env إلى GitHub.
